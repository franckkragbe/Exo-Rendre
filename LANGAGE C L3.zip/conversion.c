#include <stdio.h>
#include <stdlib.h>

int main(){
    float Montant, MontantFcfa, MontantEuro;
    const float Taux = 655.75;
    char Devise;

    printf("Choisir une devise : ");
    scanf("%c",&Devise);

    printf("Entrez le montant : \n");
    scanf("%f",&Montant);

    if(Devise="E"){
        MontantEuro = Montant/Taux;
        printf("Le montant final est : %.2f",MontantEuro);
    }else if(Devise="F"){
        MontantFcfa = Montant * Taux;
        printf("Le montant final est : %.2f",MontantFcfa);
    }
    return 0;
}


